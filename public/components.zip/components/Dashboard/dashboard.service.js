angular.module('myApp').factory('dashboardService', ['$http',function($http) {

return{

}
}]);
